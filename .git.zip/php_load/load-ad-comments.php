<?php 
include('../inc/session.inc.php');
include('../inc/db.inc.php');

$ad_id = htmlentities($_POST['ad_id']);		
$date = date('Y-m-d');
$time = date('H:i:s');

echo"
	";
?>