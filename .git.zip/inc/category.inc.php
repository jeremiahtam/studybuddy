<option>Animals & Pet supplies</option> 
<option>Apparels & Accessories </option>
<option>Arts & Entertainment </option>
<option>Electronics </option>
<option>Fashion </option>
<option>Food & beverages </option>
<option>Furniture </option>
<option>Hardware </option>
<option>Health & Beauty </option>
<option>Home & Garden </option>
<option>Luggage & Bags </option>
<option>Media </option>
<option>Office Supplies</option> 
<option>Religious & Ceremonial </option>
<option>Software </option>
<option>Sporting Goods </option>
<option>Toys & Games </option>
<option>Work & Industrial</option>
